# Library API

Esta API realiza o controle de alunos da biblioteca da Universidade. Nela é possível controlar todos os alunos, catálogo de livros e empréstimos realizado.