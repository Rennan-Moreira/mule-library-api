# Students

Na API de Alunos é permitido apenas à secretaria criar, atualizar e excluir alunos. A biblioteca pode acessar o cadastro de alunos.